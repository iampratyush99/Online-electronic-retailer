<!DOCTYPE html>
<html >
<head>
  <meta charset="UTF-8">
  <title>LOGIN</title>
  
  
  
      <link rel="stylesheet" href="css/regstyle.css">






</head>

<body>
  	

<form action="VERIFY.php" method="post">
  <h2>ADMIN</h2>
		<p>
			<label for="Email" class="floatLabel">Email</label>
			<input id="Email" name="Email" type="text">
		</p>
		<p>
			<label for="Password" class="floatLabel">Password</label>
			<input id="Password" name="Password" type="password">
			<span>Enter Password</span>
		</p>
		
		<p>
			<input type="submit" value="LOGIN" id="submit">
		</p>
	</form>
  <script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>

    <script src="js/index.js"></script>

</body>
</html>
