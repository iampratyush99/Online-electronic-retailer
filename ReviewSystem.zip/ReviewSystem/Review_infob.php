

<?php
    
		///*********************Det database connectivity********************************
		    $ReviewID=$Review_POST['Code'];
		    $ReviewUName=$Review_POST['Name'];
		    $Reviewtext=$Review_POST['text'];
		    $Reviewpost_likes=$Review_POST['post_date'];
		    $Reviewlikes=$Review_POST['likes'];
		    $Reviewreply_to=$Review_POST['reply_to'];
		   


			$ReviewmysqlDBName = "localhost";
			$Reviewusername = "root";
			$Reviewpassword = "root";
			$Reviewdbname = "onlineretailer";
			// Create new database object
			$Reviewconn = new mysqli($ReviewmysqlDBName, $Reviewusername, $Reviewpassword, $Reviewdbname);
			//Verify connectivity
			if ($Reviewconn->connect_error)
			{
				die("Connection failed: " . $Reviewconn->connect_error);
			}
  
			$Reviewsql = "Insert into  productretailerreviews values(".$ReviewID .",'". $ReviewUName ."','". $Reviewtext ."','". $Reviewpost_likes ."',". $Reviewlikes .",'". $Reviewreply_to ."')";
			if ($Reviewconn->query($Reviewsql) === TRUE) 
			{
				echo "Created successfully";
				echo "<a  href=ReviewInfoSearch.php >Show</a><br />";
			} else 
			{
				echo "Error: " . $Reviewsql . "<br>" . $Reviewconn->error;
			}

			$Reviewconn->close();

			
			
		
       ?>
	   
	   <a href='Home.php>Home</a>