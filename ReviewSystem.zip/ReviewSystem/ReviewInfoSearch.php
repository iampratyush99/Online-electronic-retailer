<!DOCTYPE html>
<html >
<head>
  <meta charset="UTF-8">
  <title> INFORMATION SEARCH</title>
        <link rel="stylesheet" href="css/regstyle.css">
<script type="text/javascript" src="jquery-1.3.2.js"> </script>


</head>

<body>
  	

<form action=" Review_infoMenu.php" method="post">
  <h2> INFORMATION</h2>
  <div id="result">
  </div>
		
		<p>
			<label for="userName" class="floatLabel">  Name</label>
			<input id=" userName" name=" userName" type="text">
			
		</p>
		
		<p>
			<input type="submit" value="Search" id="submit">
		</p>
	</form>
  <script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>

    <script src="js/index.js"></script>

</body>
</html>
