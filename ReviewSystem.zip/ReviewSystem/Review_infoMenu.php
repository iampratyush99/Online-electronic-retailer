
<html >
<head>
<title> ONLINE REWIEW RETAILER Data</title>

</head>

<body>

<?php

			$ReviewmysqlDBName = "localhost";
			$Reviewusername = "root";
			$Reviewpost_likes = "root";
			$Reviewdbname = "onlineretailer";
			// Create new database object
			$Reviewconn = new mysqli($ReviewmysqlDBName, $Reviewusername, $Reviewpost_likes, $Reviewdbname);
			//Verify connectivity
			if ($Reviewconn->connect_error)
			{
				die("Connection failed: " . $Reviewconn->connect_error);
			}
  
			$ReviewsName=$Review_POST['userName'];
			if($ReviewsName=='')
			{
				$Reviewsql = "SELECT * from productretailerreviews";
			}
			else
			{
				$Reviewsql = "SELECT * from productretailerreviews where name like '%" . $ReviewsName . "%'" ;
			}


		$Reviewresult = $Reviewconn->query($Reviewsql);
		$Reviewstatus=0;
		if ($Reviewresult->num_rows > 0) {
			//Access data rows
			echo '<center>';
			echo '<h1> ONLINE REWIEW RETAILER Data</h1><br>';
			echo '<table border="1">';
			echo '<tr>';
			echo '<td> <b>ID</b> </th>';
			echo '<td> <b>Name </b></td>';
			echo '<td> <b>Text </b></td>';
			echo '<td> <b>Date </b></td>';
			echo '<td> <b>likes </b></td>';
			echo '<td> <b>reply_to </b></td>';

			echo '<tr>';
				
		  
		   while($Reviewrow = $Reviewresult->fetch_assoc()) {
			  
				
			   $ReviewID=	$Reviewrow["id"];
				$ReviewUName=$Reviewrow["name"];
				$ReviewText=$Reviewrow["text"];
				$Reviewpost_likes=$Reviewrow["post_date"];
				$Reviewlikes=$Reviewrow["likes"];
				$Reviewreply=$Reviewrow["reply"];
			
				
				echo '<tr>';
				echo '<td>' .$ReviewID .'</th>';
				echo '<td>' . $ReviewUName . '</td>';
				echo '<td>' . $ReviewText . '</td>';
				echo '<td>' . $Reviewpost_likes . '</td>';
				echo '<td>' . $Reviewlikes . '</td>';
				echo '<td>' . $Reviewreply . '</td>';
			
				
				
				
				
				echo '<tr>';
				
					
			   }
			   echo '</table>';
			   echo '</center>';
		}
		$Reviewconn->close();


?>

</body>
<html>

