<!DOCTYPE html>
<html >
<head>
  <meta charset="UTF-8">
  <title> ONLINE REWIEW RETAILER INFORMATION</title>
  
  
  
      <link rel="stylesheet" href="css/regstyle.css">


</head>

<body>
  	
 
<script src="https://code.jquery.com/jquery-1.12.4.min.js"></script>



<form name="frmenter" method="post" action='/ReviewSystem/Review_infob.php'>
<div id="result"></div>
  <h2>ONLINE REWIEW RETAILER INFORMATION</h2>
		<p>
			<label for="Code" class="floatLabel">Code</label>
			<input id="Code" name="Code" type="text">
		</p>
		<p>
			<label for="Name" class="floatLabel">Name</label>
			<input id="Name" name="Name" type="text">
			<span>Enter </span>
		</p>
		<p>
			<label for="text" class="floatLabel">text</label>
			<input id="text" name="text" type="text">
			<span>Enter text</span>
		</p>
		<p>
			<label for="post_date" class="floatLabel">post_date</label>
			<input id="post_date" name="post_date" type="text">
			<span>Enter post_date</span>
		</p>
		
		<p>
			<label for="likes" class="floatLabel">likes</label>
			<input id="likes" name="likes" type="text">
			<span>Enter likes </span>
		</p>
                
		<p>
			<label for="reply_to" class="floatLabel">reply_to</label>
			<input id="reply_to" name="reply_to" type="text">
			<span>reply_to </span>
		</p>
                
      

		<p>
			<input type="submit" id="btn" value="Send">
		</p>
	</form>
	
	
  <script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>

    
</body>
</html>
