<?php
    
		///*********************Det database connectivity********************************
		
			$ReviewmysqlDBName = "localhost";
			$Reviewusername = "root";
			$Reviewpassword = "root";
			$Reviewdbname = "dbms";
			// Create new database object
			$Reviewconn = new mysqli($ReviewmysqlDBName, $Reviewusername, $Reviewpassword, $Reviewdbname);
			//Verify connectivity
			if ($Reviewconn->connect_error)
			{
				die("Connection failed: " . $Reviewconn->connect_error);
			}
  
			$Reviewsql = "Insert into auth values('Abc','Hindi','hindi','movie')";
			if ($Reviewconn->query($Reviewsql) === TRUE) 
			{
				echo "New record created successfully";
			} else 
			{
				echo "Error: " . $Reviewsql . "<br>" . $Reviewconn->error;
			}

			$Reviewconn->close();

			
			
		
       ?>