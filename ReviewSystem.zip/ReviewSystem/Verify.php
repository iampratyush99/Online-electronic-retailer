

<?php 


	$Reviewuname=$Review_POST['Email'];
	$ReviewPass=$Review_POST['Password'];



	$ReviewmysqlDBName = "localhost";
	$Reviewusername = "root";
	$Reviewpassword = "root";
	$Reviewdbname = "onlineretailer";
	// Create new database object
	$Reviewconn = new mysqli($ReviewmysqlDBName, $Reviewusername, $Reviewpassword,$Reviewdbname);

	//Verify connectivity
	if ($Reviewconn->connect_error) {
		die("Connection failed: " . $Reviewconn->connect_error);
	}


	$Reviewsql = "SELECT * FROM auth";

	$Reviewresult = $Reviewconn->query($Reviewsql);
	$Reviewstatus=0;
	if ($Reviewresult->num_rows >= 0) {
	 
	   while($Reviewrow = $Reviewresult->fetch_assoc()) {
		  
		 
			if($Reviewrow["Email"]==$Reviewuname && $Reviewrow["Password"]==$ReviewPass)
			{
			 $Reviewstatus=1;
			
			}
	   }

	}
	$Reviewconn->close();


	if($Reviewstatus==1)
	{
		
		include('HOME.php');
		

	}
	else
	{
		
		echo 'Inavlid username and password';
	}

?>